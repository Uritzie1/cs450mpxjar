JAROS v1.72 README

Included:
	R1.mpx project file
	comhan.c, mpx_supt.c, and mpx_supt.h source and header files
	help and MPXFILES folders for program use
	R1.exe thought it must be recompiled and built in order to get your working directory

Use:
	The executable must be run from where it is now (in the same directory as the help and MPXFILES folders).
	The application runs correctly in 32-bit WinXP.  No other operating systems are supported.
		(Though all but the date function will work in 32-bit Win7).